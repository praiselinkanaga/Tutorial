package com.niit.ecart;

public class TestCategory {

	public static void main(String[] args) {
		Category category = new Category();
		category.setId("DR001");
		category.setName("Mary");
		category.setDescription("description");
		System.out.println(category.getId());
		System.out.println(category.getName());
		System.out.println(category.getDescription());

	}

}
